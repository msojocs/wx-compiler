module.exports = {
    successCallback: function() {},
    errorCallback: function() {}
};
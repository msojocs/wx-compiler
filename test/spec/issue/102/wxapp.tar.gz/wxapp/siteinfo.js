﻿module.exports = {
  appid: "xxx",
  api: "http://test.com/",
  approot: "http://test.com/",
  userInfo: null
};
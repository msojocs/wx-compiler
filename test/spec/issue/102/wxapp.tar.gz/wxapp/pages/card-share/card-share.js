Object.defineProperty(exports, "__esModule", {
    value: !0
});

var e = {
    container: {
        width: 300,
        height: 200,
        flexDirection: "row",
        justifyContent: "space-around",
        backgroundColor: "#ccc",
        alignItems: "center"
    }
};

exports.cardShareWxml = function(e, r) {}, exports.cardShareStyle = e;
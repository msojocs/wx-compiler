// pages/login/login.js
const app = getApp()
Page({
    /**
     * 页面的初始数据
     */
    data: {
        openid: '',
        motto: '发布',
        // 初始化用户信息：userInfo hasUserInfo
        canIUse: wx.canIUse('getUserProfile'),
        showModal: false,
        phoneNumber: "",
        userInfo: [],
        // siteroot: app.siteInfo.siteroot,
        anchor: ""
    },
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (option) {
        let that = this;
        let not_perfect_data = typeof option !== 'undefined' && option.hasOwnProperty("not_perfect_data") && option.not_perfect_data !== "undefined" ? 1 : 0;
        if (typeof option !== 'undefined' && option.hasOwnProperty("anchor") && option.anchor !== "undefined") {
            that.setData({
                anchor: option.anchor,
                not_perfect_data: not_perfect_data
            })
        }
        var _rsl = "",
            userInfo = [];
        // 随机数汉字
        var _randomUniCode = Math.floor(Math.random() * (40870 - 19968) + 19968).toString(16);
        var _randomUniCodes = Math.floor(Math.random() * (40870 - 19968) + 19900).toString(16);
        _rsl = `\\u${_randomUniCode}\\u${_randomUniCodes}`;
        // 编码转义
        _rsl = unescape(_rsl.replace(/\\u/g, "%u"))
        userInfo['nickName'] = _rsl,
            userInfo['avatarUrl'] = `${that.data.siteroot}/new_product/public/images/user_block.png`
        this.setData({
            userInfo: userInfo
        })

        if (that.data.anchor != "") {
            // 查看是否授权
            // wx.getSetting({
            //     success(res) {
            //         if (res.authSetting['scope.userInfo']) {
            //             // 已经授权，可以直接调用 getUserInfo 获取头像昵称
            //             wx.getUserInfo({
            //                 success: function (res) {
            //                     console.log(res.userInfo)
            //                 }
            //             })
            //         }
            //     }
            // })

            that.getUserInfoLogin();

        }

    },

    bindGetUserInfo() {
        console.log()
        this.getUserInfoLogin();
    },
    getUserInfoLogin() {
        let that=this;
        wx.checkSession({
            success: function () {
                wx.login({
                    success: res => {
                        wx.request({
                            url: `${that.data.siteroot}/new_product/index.php/Api/Login`, //仅为示例，并非真实的接口地址
                            data: {
                                code: res.code
                            },
                            success(resu) {
                                var openid = resu.data.openid
                                var sessionKey = resu.data.session_key
                                app.globalData.sessionKey = sessionKey

                                wx.setStorageSync('session_id', resu.data.session_id)
                                app.globalData.session_id = resu.data.session_id

                                wx.request({
                                    url: `${that.data.siteroot}/new_product/index.php/Api/Insert`,
                                    data: {
                                        openid: openid,
                                        title: that.data.userInfo.nickName,
                                        avatarUrl: that.data.userInfo.avatarUrl,
                                    },
                                    method: 'POST',
                                    header: {
                                        'content-type': 'application/x-www-form-urlencoded',
                                        "Cookie": "PHPSESSID=" + app.globalData.session_id
                                    },
                                    success: function (res) {
                                        // console.log(res.data)
                                        if (res.data.code == 0) {
                                            var info = res.data.data
                                            wx.setStorageSync('userInfo', info)
                                            app.globalData.userInfo = info
                                            let page = getCurrentPages().pop();
                                            if (page == undefined || page == null) return;
                                            page.onLoad()

                                            // 如果有锚就跳转到锚位置,如果没有就返回上一页
                                            if (that.data.anchor && that.data.anchor != "") {
                                                let url = decodeURIComponent(that.data.anchor)
                                                wx.redirectTo({
                                                    url: url
                                                })
                                            } else {
                                                wx.navigateBack({
                                                    changed: true
                                                });
                                            }
                                        }
                                    }
                                })
                            }
                        })
                    }
                })
            },
            fail: function () {
                wx.login({
                    success: res => {
                        wx.request({
                            url: `${that.data.siteroot}/new_product/index.php/Api/Login`, //仅为示例，并非真实的接口地址
                            data: {
                                code: res.code
                            },
                            success(resu) {
                                var openid = resu.data.openid
                                // var sessionKey = res.data.session_key
                                wx.setStorageSync('session_id', resu.data.session_id)
                                app.globalData.session_id = resu.data.session_id

                                if (res.errMsg == "request:ok") {
                                    wx.request({
                                        url: `${that.data.siteroot}/new_product/index.php/Api/Insert`,
                                        data: {
                                            openid: openid,
                                            title: that.data.userInfo.nickName,
                                            avatarUrl: that.data.userInfo.avatarUrl,
                                        },
                                        method: 'POST',
                                        header: {
                                            'content-type': 'application/x-www-form-urlencoded',
                                            "Cookie": "PHPSESSID=" + app.globalData.session_id
                                        },
                                        success: function (res) {
                                            // console.log(res.data)
                                            if (res.data.code == 0) {
                                                var info = res.data.data
                                                wx.setStorageSync('userInfo', info)
                                                app.globalData.userInfo = info
                                                let page = getCurrentPages().pop();
                                                if (page == undefined || page == null) return;
                                                page.onLoad()
                                                wx.navigateBack({
                                                    changed: true
                                                });
                                            }
                                        }
                                    })
                                }
                            }
                        })
                    }
                })
            }
        })
    },
    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {

    },
    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {

    },
    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {

    },
    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {

    },
    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {

    },
    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {

    },
    // getUserInfo: function (e) {
    //   var that = this;
    //    // 获取用户信息
    //     wx.getUserProfile({
    //       lang: 'zh_CN',
    //       desc: '用户登录',
    //       success: (res) => {
    //         // console.log(res.userInfo)
    //         that.setData({ userInfo: res.userInfo });
    //         that.showDialogBtn();//调用一键获取手机号弹窗（自己写的）
    //       },
    //       // 失败回调
    //       fail: () => {
    //         // 弹出错误
    //       }
    //     });
    //   // }
    // },
    //绑定手机
    getPhoneNumber: function (e) {
        var that = this;
        if (e.detail.errMsg == 'getPhoneNumber:fail user deny') {
            wx.showToast({
                title: '获取手机号失败',
                icon: 'error',
                duration: 1000
            })
            return
        }

        that.hideModal();
        wx.checkSession({
            success: function () {
                wx.login({
                    success: res => {
                        wx.request({
                            url: `${that.data.siteroot}/new_product/index.php/Api/Login`, //仅为示例，并非真实的接口地址
                            data: {
                                code: res.code
                            },
                            success(resu) {
                                var openid = resu.data.openid
                                var sessionKey = resu.data.session_key
                                app.globalData.sessionKey = sessionKey
                                wx.request({
                                    url: `${that.data.siteroot}/new_product/index.php/Api/getPhone`, //自己的解密地址
                                    data: {
                                        encryptedData: encodeURIComponent(e.detail.encryptedData),
                                        iv: encodeURIComponent(e.detail.iv),
                                        sessionKey: sessionKey
                                    },
                                    method: 'POST',
                                    header: {
                                        'content-type': 'application/x-www-form-urlencoded',
                                        "Cookie": "PHPSESSID=" + resu.data.session_id
                                    },
                                    success: function (res) {
                                        wx.setStorageSync('session_id', resu.data.session_id)
                                        app.globalData.session_id = resu.data.session_id
                                        var phone = res.data.purePhoneNumber
                                        if (phone == '') {
                                            that.getPhoneNumber()
                                        }
                                        if (res.errMsg == "request:ok") {
                                            wx.request({
                                                url: `${that.data.siteroot}/new_product/index.php/Api/Insert`,
                                                data: {
                                                    openid: openid,
                                                    title: that.data.userInfo.nickName,
                                                    avatarUrl: that.data.userInfo.avatarUrl,
                                                    phone: phone,
                                                },
                                                method: 'POST',
                                                header: {
                                                    'content-type': 'application/x-www-form-urlencoded',
                                                    "Cookie": "PHPSESSID=" + app.globalData.session_id
                                                },
                                                success: function (res) {
                                                    // console.log(res.data)
                                                    if (res.data.code == 0) {
                                                        var info = res.data.data
                                                        wx.setStorageSync('userInfo', info)
                                                        app.globalData.userInfo = info
                                                        let page = getCurrentPages().pop();
                                                        if (page == undefined || page == null) return;
                                                        page.onLoad()
                                                        // 判断有没有完善资料,如果没有带上锚跳转到完善资料页面
                                                        // if ((info.realname==null ||info.realname=="")&&that.data.not_perfect_data==0) {
                                                        //     let anchorUrl = ""
                                                        //     if (that.data.anchor != "") {
                                                        //         anchorUrl = "?anchor=" + decodeURIComponent(that.data.anchor)
                                                        //         wx.redirectTo({
                                                        //             url: '/pages/user/data/data' + anchorUrl
                                                        //         })
                                                        //     }else{
                                                        //         wx.navigateBack({
                                                        //             changed: true
                                                        //         });
                                                        //     }
                                                        // } else {
                                                        // 如果有锚就跳转到锚位置,如果没有就返回上一页
                                                        if (that.data.anchor && that.data.anchor != "") {
                                                            let url = decodeURIComponent(that.data.anchor)
                                                            wx.redirectTo({
                                                                url: url
                                                            })
                                                        } else {
                                                            wx.navigateBack({
                                                                changed: true
                                                            });
                                                        }
                                                    }



                                                }
                                                // }
                                            })
                                        }
                                    }
                                })
                            }
                        })
                    }
                })
            },
            fail: function () {
                wx.login({
                    success: res => {
                        wx.request({
                            url: `${that.data.siteroot}/new_product/index.php/Api/Login`, //仅为示例，并非真实的接口地址
                            data: {
                                code: res.code
                            },
                            success(resu) {
                                var openid = resu.data.openid
                                // var sessionKey = res.data.session_key
                                wx.request({
                                    url: `${that.data.siteroot}/new_product/index.php/Api/getPhone`, //自己的解密地址
                                    data: {
                                        encryptedData: encodeURIComponent(e.detail.encryptedData),
                                        iv: encodeURIComponent(e.detail.iv),
                                        // sessionKey: sessionKey
                                    },
                                    method: 'POST',
                                    header: {
                                        'content-type': 'application/x-www-form-urlencoded',
                                        "Cookie": "PHPSESSID=" + resu.data.session_id
                                    },
                                    success: function (res) {
                                        wx.setStorageSync('session_id', resu.data.session_id)
                                        app.globalData.session_id = resu.data.session_id
                                        var phone = res.data.purePhoneNumber
                                        if (phone == '') {
                                            that.getPhoneNumber()
                                        }
                                        if (res.errMsg == "request:ok") {
                                            wx.request({
                                                url: `${that.data.siteroot}/new_product/index.php/Api/Insert`,
                                                data: {
                                                    openid: openid,
                                                    title: that.data.userInfo.nickName,
                                                    avatarUrl: that.data.userInfo.avatarUrl,
                                                    phone: phone,
                                                },
                                                method: 'POST',
                                                header: {
                                                    'content-type': 'application/x-www-form-urlencoded',
                                                    "Cookie": "PHPSESSID=" + app.globalData.session_id
                                                },
                                                success: function (res) {
                                                    // console.log(res.data)
                                                    if (res.data.code == 0) {
                                                        var info = res.data.data
                                                        wx.setStorageSync('userInfo', info)
                                                        app.globalData.userInfo = info
                                                        let page = getCurrentPages().pop();
                                                        if (page == undefined || page == null) return;
                                                        page.onLoad()
                                                        wx.navigateBack({
                                                            changed: true
                                                        });
                                                    }
                                                }
                                            })
                                        }
                                    }
                                })
                            }
                        })
                    }
                })
            }
        })
    },
    // 显示一键获取手机号弹窗
    showDialogBtn: function () {
        this.setData({
            showModal: true //修改弹窗状态为true，即显示
        })
    },
    // 隐藏一键获取手机号弹窗
    hideModal: function () {
        this.setData({
            showModal: false //修改弹窗状态为false,即隐藏
        });
    },
})
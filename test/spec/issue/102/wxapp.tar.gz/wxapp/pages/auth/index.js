var e = getApp(),  m = getApp(), o = require("../../utils/core.js");
const defaultAvatarUrl = 'https://mmbiz.qpic.cn/mmbiz/icTdbqWNOwNRna42FI242Lcia07jQodd2FJGIYQfG0LAJGFxM4FbnQP6yfMxBgJ0F3YRqJCJ1aPAK2dQagdusBZg/0'

Page({
    data: {
        shop_logo: "",
        shop_name: "",
        canIUseGetUserProfile: !1,
        sessionInfo: !1,
        nickname:'',
        anchor:'',
        agreement:false,
        avatarUrl: defaultAvatarUrl
    },
    onLoad: function(e) {
        var n = this, s = !1, t = wx.getSystemInfoSync().SDKVersion;
        wx.getUserProfile && this.compareVersion(t, "2.16.0") >= 0 ? (s = !0, this.getSession()) : s = !1, 
        o.get("wxAppSetting", {}, function(e) {
            var o = e.sysset;
            n.setData({
                shop_logo: o.shoplogo,
                shop_name: o.shopname,
                canIUseGetUserProfile: s
            });
        });
    },
    getSession: function() {
      wx.showLoading({
          title: "加载中"
      }), this.wxLogin();
    },
    wxLogin: function(e) {
      var _this = this;
      wx.showLoading({
          title: "加载中"
      }), wx.login({
          success: function(s) {
          
              console.warn("wx.login", s), o.post("wxapp/login", {
                  code: s.code
              }, function(s) {
                console.log("87777");
                console.log(s);
                  if (console.warn("post wxapp/login", s), s.error) return n.alert("获取用户登录态失败:" + s.message), 
                  !1;
                  "function" == typeof e && e(s.session_key), _this.setData({
                      sessionInfo: s,
                      anchor: s.anchor,
                  });
                  if(s.anchor==1)
                  {
                    console.log( s.member);
                    _this.setData({
                      nickname: s.member.nickname,
                      avatarUrl: s.member.avatar,
                  });
                  }
              });
          },
          fail: function() {
              o.alert("获取用户信息失败(wx.login)");
          },
          complete: function() {
              wx.hideLoading();
          }
      });
    },
    compareVersion: function(e, n) {
      e = e.split("."), n = n.split(".");
      for (var o = Math.max(e.length, n.length); e.length < o; ) e.push("0");
      for (;n.length < o; ) n.push("0");
      for (var s = 0; s < o; s++) {
          var t = parseInt(e[s]), i = parseInt(n[s]);
          if (t > i) return 1;
          if (t < i) return -1;
      }
      return 0;
    },
    bindGetUserInfobu(){
      //getUserProfile获取用户信息
     wx.getUserProfile({
      lang:'zh_CN',
      desc: '用于完善会员资料',
      success: (res) =>{
        console.log(res)
        //getUserInfo获取认证oid解密
        wx.getUserInfo({
          lang: 'zh_CN',
        }).then(r=>{
          console.log(r)
         r.userInfo=res.userInfo
          let n={
            detail:r
           }
           this.bindGetUserInfo(n)
        })
      }
     })
    },
    bindGetUserInfo: function(n) {
      const _this = this;
        wx.showLoading({
            title: "加载中"
        }), wx.login({
            success: function(i) {
                console.log([ 1, i ]), o.post("wxapp/login", {
                    code: i.code
                }, function(i) {
                  
                    console.log([ 2, i ]), i.error ? o.alert("获取用户登录态失败:" + i.message) : o.get("wxapp/auth", {
                        data: n.detail.encryptedData,
                        iv: n.detail.iv,
                        sessionKey: i.session_key,
                        avatar: _this.data.avatarUrl==defaultAvatarUrl ? '' : _this.data.avatarUrl,
                        nickname: _this.data.nickname
                    }, function(s) {
                        console.log([ 3, s ]), 1 == s.isblack && wx.showModal({
                            title: "无法访问",
                            content: "您在商城的黑名单中，无权访问！",
                            success: function(o) {
                                o.confirm && e.close(), o.cancel && e.close();
                            }
                        }), n.detail.userInfo.openid = s.openId, n.detail.userInfo.id = s.id, n.detail.userInfo.uniacid = s.uniacid;
                        var t = e.setCache("userinfo", n.detail.userInfo), a = e.setCache("userinfo_openid", n.detail.userInfo.openid), c = e.setCache("userinfo_id", s.id);
                        console.log(e.getCache("userinfo")), console.log(e.getCache("userinfo_openid")), 
                        console.log(e.getCache("userinfo_id"));
                        var l = e.setCache("login_session_key", i.session_key);
                        0 != t && 0 != a && 0 != c && 0 != l || o.alert("获取用户信息失败!"), console.log(e.getCache("login_session_key")), 
                        e.getSet(), e.scanCarts(), wx.navigateBack({
                            changed: !0
                        });
                    });
                });
            },
            fail: function() {
                o.alert("获取用户信息失败!");
            },
            complete: function() {
                wx.hideLoading();
            }
        });
    },
    checkboxChange(e) {
 

      this.setData({
          agreement:!this.data.agreement
      })
    },
      //绑定手机
      getPhoneNumber: function (n) {
        var that = this;

        
        if (n.detail.errMsg == 'getPhoneNumber:fail user deny') {
            wx.showToast({
                title: '获取手机号失败',
                icon: 'error',
                duration: 1000
            })
            return
        }
        console.log("console.log(e.detail);");
        console.log(e.detail);
        var userInfo=[];
        that.hideModal();
        wx.checkSession({
            success: function () {
              wx.login({
                success: function(i) {
                    console.log([ 1, i ]), o.post("wxapp/login", {
                        code: i.code
                    }, function(i) {
                      console.log("5555555555555555");
                      var log_openid=i.openid;
                      console.log(i.openid);
                        console.log([ 2, i ]), i.error ? o.alert("获取用户登录态失败:" + i.message) : o.get("wxapp/authmobile", {
                            data: n.detail.encryptedData,
                            iv: n.detail.iv,
                            sessionKey: i.session_key,
                            log_openid:log_openid,
                            avatar: that.data.avatarUrl==defaultAvatarUrl ? '' : that.data.avatarUrl,
                            nickname: that.data.nickname
                        }, function(s) {
                          if(s.error==9900001)
                          {
                            o.alert(s.message);
                          }else{
                            console.log([ 3, s ]), 1 == s.isblack && wx.showModal({
                              title: "无法访问",
                              content: "您在商城的黑名单中，无权访问！",
                              success: function(o) {
                                  o.confirm && e.close(), o.cancel && e.close();
                              }
                          })
                          ,userInfo.openid = s.openId,userInfo.id = s.id, userInfo.uniacid = s.uniacid;
                          var t = m.setCache("userinfo",userInfo), a = m.setCache("userinfo_openid",userInfo.openid), c = e.setCache("userinfo_id", s.id);
                          console.log(e.getCache("userinfo")), console.log(e.getCache("userinfo_openid")), 
                          console.log(e.getCache("userinfo_id"));
                          var l = e.setCache("login_session_key", i.session_key);
                          0 != t && 0 != a && 0 != c && 0 != l || o.alert("获取用户信息失败!"), console.log(e.getCache("login_session_key")), 
                          e.getSet(), e.scanCarts(), wx.navigateBack({
                              changed: !0
                          });
                          }

                           
                        });
                    });
                },
                fail: function() {
                    o.alert("获取用户信息失败!");
                },
                complete: function() {
                    wx.hideLoading();
                }
            });
            },
            fail: function () {
               
            }
        })
    },
    navigateBack: function() {
        wx.navigateBack({
            changed: !0
        });
    },
    close: function() {
        wx.navigateBack({
            delta: 0
        });
    },
    bindblur(e) {
      this.setData({
        nickname:e.detail.value
      })
    },
      // 显示一键获取手机号弹窗
      showDialogBtn: function () {
        this.setData({
            showModal: true //修改弹窗状态为true，即显示
        })
    },
    // 隐藏一键获取手机号弹窗
    hideModal: function () {
        this.setData({
            showModal: false //修改弹窗状态为false,即隐藏
        });
    },
    bindinput(e){
      this.setData({
        nickname:e.detail.value//这里要注意如果只用blur方法的话用户在输入玩昵称后直接点击保存按钮，会出现修改不成功的情况。
      })
    },
    onChooseAvatar(e) {
      var that = this;
      const { avatarUrl } = e.detail 
      this.setData({
        avatarUrl,
      })
      var a = o.getUrl("util/uploader/upload", {
        file: "file"
      })
      console.log(a);
      wx.uploadFile({
          url: a,
          filePath: avatarUrl,
          name: "file",
          success: function(n) {
              wx.hideLoading();
              // console.log(n);
              var a = JSON.parse(n.data);
              console.log(a.files[0]['url']);
              that.setData({
                avatarUrl:a.files[0]['url']
              })
          }
      });
    }
});